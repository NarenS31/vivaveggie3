#!/bin/bash
# Script to start Next.js application

echo "Starting Next.js app with turbopack..."
exec npx next dev --turbo