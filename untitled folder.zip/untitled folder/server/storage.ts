// This file exists for compatibility purposes
// The application now uses Next.js architecture
export {};